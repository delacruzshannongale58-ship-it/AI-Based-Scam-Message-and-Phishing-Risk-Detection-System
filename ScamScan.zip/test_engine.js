const E = require("./engine.js"); const M = require("./model.js");
const tests = [
 "GCASH ALERT: Your account will be suspended within 24 hours. Verify now: bit.ly/gcash-verify1 and send the OTP we text you to keep your account active.",
 "Congratulations! You won PHP 50,000. Click to claim and enter your card number.",
 "Your parcel is on hold. Pay a PHP 49 release fee at the link to receive it today.",
 "Hi, are we still meeting at 3 pm at the library?",
 "Your OTP is 482913. It expires in 5 minutes. Do not share this code with anyone.",
 "Never share the verification code with anyone, even our staff.",
 "GCash: You have received PHP 500.00 from Juan.",
 "Nanalo ka sa promo! Ibigay ang iyong OTP para makuha ang premyo.",
];
for (const t of tests) { const r = E.analyze(t, M);
  console.log(r.label.padEnd(16), r.level.padEnd(6), "P="+r.p.toFixed(3), "pts="+r.points, "S="+r.score.toFixed(3), "|", r.indicators.map(i=>i.id).join(","), "\n   ", t.slice(0,70)); }
// parity export for python check
require("fs").writeFileSync("/tmp/parity_js.json", JSON.stringify(tests.map(t=>E.predictProbability(t,M))));
